import tkinter as tk
import time

class Ball:
    def __init__(self,canvas:tk.Canvas,color,paddle):
        self.canvas=canvas
        self.id=canvas.create_oval(0,0,15,15,fill=color)   
        self.canvas.move(self.id,245,100)
        self.x=-2
        self.y=3
        self.paddle=paddle
        
    def drow(self):
        p_cord=self.canvas.coords(self.paddle.id)
        self.canvas.move(self.id,self.x,self.y)
        coords=self.canvas.coords(self.id)
        if coords[3]>=400:
            self.y=-3
        elif coords[0]<=0:
            self.x=3
        elif coords[1]<=0:
            self.y=3
        elif coords[2]>=500:
            self.x=-3
        if self.chek(coords,p_cord):
            self.y=-3
            
    def chek(self,cord,p_cord):
        if cord[2]>p_cord[0] and cord[0]<p_cord[2]:
            if cord[3]>p_cord[1] and cord[3]<p_cord[3]:
                return True
        return False
        
class Paddle:
    def __init__(self,canvas:tk.Canvas,color):
        self.canvas=canvas
        self.id=canvas.create_rectangle(0,0,100,10,fill=color)   
        self.canvas.move(self.id,200,370)
        self.x=0
        self.canvas.bind_all("<Left>",self.left)
        self.canvas.bind_all("<Right>",self.right)
        
    def drow(self):
        self.canvas.move(self.id,self.x,0)
        coords=self.canvas.coords(self.id)
        if coords[0]<=0:
            self.x=3
        elif coords[2]>=500:
            self.x=-3   
            
    def left(self,e):
        self.x=-3
        
    def right(self,e):
        self.x=3

t=tk.Tk()
t.geometry("500x400")
t.title("jump")
t.resizable(0,0)
t.wm_attributes("-topmost",1)
canvas=tk.Canvas(t,width=500,height=400,bd=0,highlightthickness=0)
canvas.pack()
t.update()

paddle=Paddle(canvas,"green")
ball=Ball(canvas,"red",paddle)







while True:
    t.update()
    t.update_idletasks()
    ball.drow()
    time.sleep(0.01)
    paddle.drow()